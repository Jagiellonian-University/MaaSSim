################################################################################
# Module: __main__.py
# MaasSim main
# Rafal Kucharski @ TU Delft
################################################################################

if __name__ == "__main__":
    from MaaSSim.simulators import simulate
    simulate()